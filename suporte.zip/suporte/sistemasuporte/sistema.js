
function menuOpen(){
document.querySelector(".menu-lateral").style.width="200px";
document.querySelector(".nav-item").style.marginLeft="100px";



}


function menuClose(){
    document.querySelector(".menu-lateral").style.width="0px";
    document.querySelector(".nav-item").style.marginLeft="0px";
    
}

