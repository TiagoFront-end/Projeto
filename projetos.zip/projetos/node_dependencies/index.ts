function teste(nome: string){
    console.log("olá estudante", nome)
}
teste("nome: Tiago");