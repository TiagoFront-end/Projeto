function teste(nome) {
    console.log("olá estudante", nome);
}
teste("nome: Tiago");
