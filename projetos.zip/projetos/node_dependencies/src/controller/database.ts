const database: = [
    "Tiago",
]

export { database }  