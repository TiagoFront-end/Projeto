import {Router} from 'express'
import { userController, userController } from './controller/usersController.js'

const routes = Router()
const userController = new userController()

// quatros  elementos  HTTP
// GET:ler os dados
// POST: criar os dados
//PUT/PATCH: editar os  dados
//DELETE: deletar  os dados



routes.get('/users', usersController.listarUser) 

routes.post('/users',userController.criarUsuarios)

//Status Codes
// 200 e 201
//404  pagina nao  encontrada

export {routes}