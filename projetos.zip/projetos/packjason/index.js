

// evento  de loop

function loop(){
var a =1;
var b =2;
var c =3;
console.log(a);





setTimeout(() =>{
 console.log(b);
},2000);
console.log(c);

}

loop();

