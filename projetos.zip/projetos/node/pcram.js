const os = require('os');
// console.log(os);


const{arch, freemem,platform,totalmem} = os;

// tratando  variaveis
setInterval(()=>{
    const tRam = totalmem()/1024/1024;
    const fRam = freemem()/1024/1024;
    const usage = (fRam / tRam) * 100;
    const status = {
        os:platform(),
        arch:arch(),
        freeram: `${parseInt(fRam)}MB`,
        totalRam: `${parseInt(tRam)}MB`,
       usage:`${usage.toFixed(3)}%`,
    };
    console.clear();
  console.table(status);  
    // exportando  modulo

    exports.status = status;
},1000);
