const cep = document.querySelector("#cep")
const showData = (resultado) => {
    for(var campo in resultado){
        if(document.querySelector("#"+campo)){
        document.querySelector("#"+campo).value = resultado[campo]
    }
 
}

}

cep.addEventListener("blur", function(e){

let search = cep.value.replace("-", "")
const options = {
    method: 'GET',
    mode: 'cors',
    cache: 'default'
}
    console.log(cep.value)
fetch(`https://viacep.com.br/ws/${search}/json/`, options)
.then(response =>{response.json()
    .then( data => showData(data))
})
.catch( e => console.error('Deu Erro: ' + e.message))
})