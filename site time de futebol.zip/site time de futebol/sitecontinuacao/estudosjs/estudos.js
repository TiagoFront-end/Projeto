/*let alunos = [];
console.log(alunos);
let alunos1 = ['Miguel'];
//trabalhando com vetores  atraves  de prompt e com metodo  orientado a objeto
//var profissao =prompt("insira  sua profissao", new Array());
//var cargo = new Array("",prompt("seu cargo ?"));
var profissao = new Array();
var cargo = new Array("Analista De Suporte"," Administrador de banco de Dados");
cargo.push("Programador","Analista  de Teste");// adicionando itens//
cargo[cargo.length]= "Instrutor De  Programação";//adicionando elemento atraves do tamanho do array
cargo.splice(3,0,'Front-end');// adicionando a partir de um novo índice//
cargo.splice(4,'DBA','LINKWAP','TESTE');// substituindo  e adicionando elemento a partir de  seu indice
cargo.splice(3);// excluindo eleemento  a partir do  indice
cargo.splice(2,3,"DBA","Banco De Dados","PHP");
//delete cargo[2];//   nao  remove e  sim o torna undefined
//alert(cargo.length);
cargo.pop(); // exclui o ultimo elemento do array
cargo.shift(); //exclui  um elemento do inicio do array tornando o proximo que restar o  indice 0
document.getElementById("profissao").innerHTML="sua Profissão é ?: "+profissao;
document.getElementById("cargo").innerHTML="Seu Cargo é : "+cargo;*/

numeros [0] = insiraoprimeiroNumero();
numeros [1] = insiraosegundoNumero();

