fetch() 
.the()({

})

.catch(function(){

});

const ul = document.getElementById('telefone');
const url ='https://api.directcallsoft.com/voz/call';

console.log(url);

console.log('teste')