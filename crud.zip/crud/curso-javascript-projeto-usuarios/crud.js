let nome = document.querySelector("#exampleInputName"); 
let genero = document.querySelector("#exampleInputGenderM");
let DtNascimento = document.querySelector("#exampleInputBirth");
let Country = document.querySelector("#exampleInputCountry");
let email = document.querySelector("#exampleInputEmail1");
let password = document.querySelector("#exampleInputPassword1");
let file = document.querySelector("#exampleInputFile");
let admin = document.querySelector("#exampleInputAdmin");
document.querySelectorAll("#form-user-create [name=gender]"); // puxando  todos os  campos do  formulário//
// let  form = document.querySelectorAll("form-user-create");// buscando conteudo de um campo pelo id
document.querySelectorAll("#-user-create [name=gender]:checked");// escolhe os  campos pelo checked//

let fieldsForm = document.querySelectorAll("#form-user-create [name]");

fieldsForm.forEach((fieldsFrom, index) =>{ // usando arrow function função sem o nome function apenas com sinal de igualdade  e maior que

console.log(fieldsForm)

fieldsForm.name >=  "gender" ? "gender " : true;

console.log(fieldsForm.name);

});
